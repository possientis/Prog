require("install")    -- Install lazy package manager
require("plugins")    -- Install all plugins by setting up lazy
require("syntax")     -- Set up nvim-treesitter
require("lsp")        -- Set up mason-lspconfig
require("completion") -- Set up nvim-cmp       
require("keymaps")     -- Key mappings
require("settings")   -- Various settings 

