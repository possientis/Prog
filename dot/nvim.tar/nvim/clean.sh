#!/bin/sh

# removes existing state for neovim: useful to check existing config works
sudo rm -rf /home/noel/.local/share/nvim
sudo rm -rf /home/noel/.local/state/nvim
rm -f lazy-lock.json 
